import tkinter as tk
import math
 

#programmas logs
window = tk.Tk()
window.title("Pomodoro taimeris")
window.geometry("400x300")
window.configure(bg="#BFF4BE")
window.resizable(False, False)

#notikumi
darbs =5*1000 #25 *60 * 1000 #10*1000
pauze = 2*1000 #5*60 * 1000 #5*1000
gara_pauze = 5*1000#25*60*1000 #10*1000
cikli = 4
cikli_sakums = 0

def sakt_taimeri():
    global cikli_sakums
    cikli_sakums = 0
    sakt.pack_forget()
    sakt_darbu()

def sakt_darbu():
    global cikli_sakums
    if cikli_sakums < cikli:
        teksts1.config(text = "Lietotājs strādā (25 min)")
        window.after(darbs, sakt_pauzes)
    else:
        sakt_garo_pauzi()

def sakt_pauzes():
    global cikli_sakums
    cikli_sakums = cikli_sakums +1
    if cikli_sakums < cikli:
        teksts1.config(text = "Lietotājs atpūšas (5 min)")
        window.after(pauze, sakt_darbu)
    else:
        sakt_garo_pauzi()

def sakt_garo_pauzi():
    teksts1.config(text = "Lietotājs atpūšas (25 min)")
    window.after(gara_pauze, beigu_ekrans)

def beigu_ekrans():
    teksts1.config(text= "Vēlies sākt taimeri no jauna?")
    sakt.pack()


#starta logs
sakt = tk.Button (window, text = "Sākt", command = sakt_taimeri, width = 6, height = 2, font = ('Verdana', 8, 'bold'))
sakt.pack(side = tk.BOTTOM, pady = 20)
image1 = tk.PhotoImage(file=r'resources/tomats1.png')
bilde = tk.Label(window, image = image1, bg = "#BFF4BE")
bilde.place(x=5, y = 5)
teksts1 = tk.Label(window, text = "Pomodoro taimeris", font = ("Times New Roman", 20), bg = "#BFF4BE")
teksts1.pack(anchor = tk.CENTER, pady = 100)

window.mainloop()

